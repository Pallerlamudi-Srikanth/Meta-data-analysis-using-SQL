USE ig_clone;

-- instagram users data over view
SELECT
    (SELECT COUNT(*) FROM users) AS total_users,
    (SELECT COUNT(*) FROM photos) AS total_photos,
    (SELECT COUNT(*) FROM comments) AS total_comments,
    (SELECT COUNT(*) FROM likes) AS total_likes;

-- number of instagram users who haven't posted a single photo since creation 
SELECT 
    u.id,
    u.username
FROM users u
WHERE NOT EXISTS (
    SELECT 1 
    FROM photos p 
    WHERE p.user_id = u.id
)
ORDER BY u.id;

-- number of posts per tag category 
SELECT t.tag_name,
       COUNT(DISTINCT pt.photo_id) AS number_of_posts 
FROM tags t 
JOIN photo_tags pt on t.id = pt.tag_id 
GROUP BY t.tag_name
ORDER BY number_of_posts DESC;

-- Total number of posts made 
SELECT COUNT(DISTINCT id) FROM photos;

-- Total number of followers of each users 
SELECT u.id ,
	   u.username,
	   COUNT(DISTINCT f.follower_id) AS number_of_followers
FROM users u 
LEFT JOIN follows f on u.id = f.followee_id
GROUP BY u.id , u.username
ORDER BY number_of_followers DESC;

-- number of posts per tag name 
SELECT t.tag_name,
       COUNT(DISTINCT pt.photo_id) AS number_of_photos_per_tag
FROM tags t 
LEFT JOIN photo_tags pt on t.id = pt.tag_id
GROUP BY t.tag_name 
ORDER BY number_of_photos_per_tag DESC;

-- Objective Question - 2 
SELECT u.id,
       u.username,
	   COUNT(DISTINCT p.id) AS number_of_photos,
       COUNT(DISTINCT l.photo_id) AS number_of_likes,
       COUNT(c.id) AS number_of_comments,
       ROUND((COUNT(DISTINCT l.photo_id)+COUNT(c.id))*1.0/NULLIF(COUNT(DISTINCT p.id),0),2) AS average_engagement_per_post
FROM users u 
LEFT JOIN photos p on u.id = p.user_id
LEFT JOIN likes l on p.id = l.photo_id 
LEFT JOIN comments c on p.id = c.photo_id
GROUP BY u.id , u.username ;

-- Objective Question 3 
-- Average number of tags per photo
SELECT
    ROUND(
        COUNT(pt.photo_id) * 1.0 / COUNT(DISTINCT p.id),
        2
    ) AS avg_tags_per_post_all_photos
FROM photos p
LEFT JOIN photo_tags pt ON pt.photo_id = p.id;

-- objective question - 4 
SELECT 
    u.username,
    COUNT(DISTINCT p.id) AS posts,
    COUNT(l.photo_id) AS likes_received,
    COUNT(c.id) AS comments_received,
    (COUNT(l.photo_id) + COUNT(c.id)) AS total_engagement,
    ROUND(
        (COUNT(l.photo_id) + COUNT(c.id)) * 1.0 / COUNT(DISTINCT p.id), 
    2) AS avg_engagement_per_post
FROM users u
JOIN photos p ON u.id = p.user_id
LEFT JOIN likes l ON p.id = l.photo_id
LEFT JOIN comments c ON p.id = c.photo_id
GROUP BY u.id, u.username
ORDER BY total_engagement DESC;

-- objective question - 5 
-- user with highest number of followers
SELECT u.id,
       u.username,
       COUNT(DISTINCT f1.follower_id) AS number_of_followers,
       COUNT(DISTINCT f2.followee_id) AS number_of_following
FROM users u 
LEFT JOIN follows f1 on u.id = f1.followee_id
LEFT JOIN follows f2 on u.id = f2.follower_id
GROUP BY u.id, u.username
ORDER BY number_of_followers DESC 
LIMIT 1; 

-- user with highest number of following 
SELECT u.id,
       u.username,
       COUNT(DISTINCT f1.follower_id) AS number_of_followers,
       COUNT(DISTINCT f2.followee_id) AS number_of_following
FROM users u 
LEFT JOIN follows f1 on u.id = f1.followee_id
LEFT JOIN follows f2 on u.id = f2.follower_id
GROUP BY u.id, u.username
ORDER BY number_of_following DESC 
LIMIT 1;

-- objective question - 6 
SELECT 
    u.username,
    COUNT(DISTINCT p.id) AS posts,
    COUNT(l.photo_id) AS likes_received,
    COUNT(c.id) AS comments_received,
    ROUND(
        (COUNT(l.photo_id) + COUNT(c.id)) * 1.0 / COUNT(DISTINCT p.id), 
    2) AS avg_engagement_per_post
FROM users u
JOIN photos p ON u.id = p.user_id
LEFT JOIN likes l ON p.id = l.photo_id
LEFT JOIN comments c ON p.id = c.photo_id
GROUP BY u.id, u.username
ORDER BY avg_engagement_per_post DESC;

-- objective question - 7 
SELECT 
    u.id,
    u.username
FROM users u
WHERE NOT EXISTS (
    SELECT 1 
    FROM likes l 
    WHERE l.user_id = u.id
)
ORDER BY u.username;

-- objective question - 8 
-- High engagement hashtags (from earlier)
SELECT 
    t.tag_name,
    COUNT(DISTINCT pt.photo_id) AS posts,
    ROUND((COUNT(l.user_id) + COUNT(c.id)) * 1.0 / COUNT(DISTINCT pt.photo_id), 2) AS avg_engagement
FROM tags t
JOIN photo_tags pt ON t.id = pt.tag_id
LEFT JOIN likes l ON pt.photo_id = l.photo_id
LEFT JOIN comments c ON pt.photo_id = c.photo_id
GROUP BY t.tag_name
ORDER BY avg_engagement DESC;

-- objective question - 9
-- Activity level vs Content Themes
SELECT 
    CASE 
        WHEN COUNT(DISTINCT p.id) = 0 THEN 'Inactive'
        WHEN COUNT(DISTINCT p.id) <= 2 THEN 'Low Activity'
        WHEN COUNT(DISTINCT p.id) <= 5 THEN 'Moderate'
        ELSE 'High Activity'
    END AS activity_level,
    t.tag_name,
    COUNT(DISTINCT pt.photo_id) AS posts_with_tag
FROM users u
LEFT JOIN photos p ON u.id = p.user_id
LEFT JOIN photo_tags pt ON p.id = pt.photo_id
LEFT JOIN tags t ON pt.tag_id = t.id
GROUP BY t.tag_name
ORDER BY activity_level, posts_with_tag DESC;

-- objective question - 10
SELECT 
    u.username,
    COUNT(DISTINCT l.photo_id) AS number_of_likes,
    COUNT(DISTINCT c.id) AS number_of_comments,
    COUNT(DISTINCT pt.tag_id) AS tags_on_their_photos,
    COUNT(pt.photo_id) AS total_tag_usages_on_their_photos
FROM users u
LEFT JOIN likes l ON u.id = l.user_id
LEFT JOIN comments c ON u.id = c.user_id
LEFT JOIN photos p ON u.id = p.user_id
LEFT JOIN photo_tags pt ON p.id = pt.photo_id
GROUP BY u.id, u.username
ORDER BY number_of_likes DESC, number_of_comments DESC;

-- objective question - 11 
SELECT 
    u.id,
    u.username,
    DATE_FORMAT(p.created_at, '%Y-%m') AS month,
    
    COUNT(DISTINCT p.id) AS posts_in_month,
    COUNT(DISTINCT l.user_id) AS likes_received,
    COUNT(DISTINCT c.id) AS comments_received,
    
    (COUNT(DISTINCT l.user_id) + COUNT(DISTINCT c.id)) AS total_engagement,
    
    ROUND(
        (COUNT(DISTINCT l.user_id) + COUNT(DISTINCT c.id)) * 1.0 
        / NULLIF(COUNT(DISTINCT p.id), 0), 
    2) AS engagement_per_post

FROM users u
JOIN photos p ON u.id = p.user_id
LEFT JOIN likes l ON p.id = l.photo_id
LEFT JOIN comments c ON p.id = c.photo_id
GROUP BY u.id, u.username, DATE_FORMAT(p.created_at, '%Y-%m')
HAVING total_engagement > 0
ORDER BY month DESC, total_engagement DESC;

-- objective question - 12
-- Hashtags with Highest Average Likes per Post
WITH tag_stats AS (
    SELECT 
        t.tag_name,
        COUNT(DISTINCT pt.photo_id) AS num_posts_using_tag,
        COUNT(l.photo_id) AS total_likes_on_tagged_posts,
        ROUND(
            COUNT(l.photo_id) * 1.0 / NULLIF(COUNT(DISTINCT pt.photo_id), 0), 
        2) AS avg_likes_per_post
    FROM tags t
    JOIN photo_tags pt ON t.id = pt.tag_id
    LEFT JOIN likes l ON pt.photo_id = l.photo_id
    GROUP BY t.tag_name
    HAVING COUNT(DISTINCT pt.photo_id) >= 3   -- At least 3 posts to be meaningful
)
SELECT 
    tag_name,
    num_posts_using_tag,
    total_likes_on_tagged_posts,
    avg_likes_per_post
FROM tag_stats
ORDER BY avg_likes_per_post DESC, num_posts_using_tag DESC;

-- objective question - 13 
SELECT 
    f1.follower_id AS user_id,
    follower.username AS user_name,
    f1.followee_id AS followed_user_id,
    followee.username AS followed_user_name,
    f2.created_at AS was_followed_at,           -- When the other person followed them first
    f1.created_at AS started_following_at,      -- When this user followed back
    DATEDIFF(f1.created_at, f2.created_at) AS days_later
FROM follows f1
JOIN follows f2 ON f1.follower_id = f2.followee_id 
               AND f1.followee_id = f2.follower_id
JOIN users follower ON f1.follower_id = follower.id
JOIN users followee ON f1.followee_id = followee.id
WHERE f1.created_at > f2.created_at          -- Followed back later
ORDER BY days_later DESC, f1.created_at DESC;

-- Subjective question - 1 
SELECT 
    u.id,
    u.username,
    
    COUNT(DISTINCT p.id) AS posts,
    COUNT(DISTINCT l.photo_id) AS likes_given,
    COUNT(DISTINCT c.id) AS comments_made,
    
    -- Loyalty / Value Score
    (COUNT(DISTINCT p.id) * 3) +                   
    (COUNT(DISTINCT l.photo_id) * 1) +
    (COUNT(DISTINCT c.id) * 2) AS loyalty_score

FROM users u
LEFT JOIN photos p ON u.id = p.user_id
LEFT JOIN likes l ON u.id = l.user_id
LEFT JOIN comments c ON u.id = c.user_id
GROUP BY u.id, u.username
ORDER BY loyalty_score DESC;

-- subjective question - 2
SELECT 
    u.id,
    u.username
FROM users u
WHERE NOT EXISTS (
    SELECT 1 
    FROM photos p 
    WHERE p.user_id = u.id
)
ORDER BY u.id;
-- Subjective Question - 3 
WITH tag_engagement AS (
    SELECT 
        t.tag_name,
        COUNT(DISTINCT pt.photo_id) AS posts_using_tag,
        COUNT(DISTINCT l.user_id) AS total_likes,
        COUNT(DISTINCT c.id) AS total_comments,
        ROUND(
            (COUNT(DISTINCT l.user_id) + COUNT(DISTINCT c.id)) * 1.0 
            / NULLIF(COUNT(DISTINCT pt.photo_id), 0), 
        2) AS avg_engagement_per_post
    FROM tags t
    JOIN photo_tags pt ON t.id = pt.tag_id
    LEFT JOIN likes l ON pt.photo_id = l.photo_id
    LEFT JOIN comments c ON pt.photo_id = c.photo_id
    GROUP BY t.tag_name
    HAVING COUNT(DISTINCT pt.photo_id) >= 3   -- filter low-usage tags
)
SELECT *
FROM tag_engagement
ORDER BY avg_engagement_per_post DESC;

-- Subjective question - 4 
-- user tenure
-- 1. Engagement by User Tenure (New vs Old users)
SELECT 
    CASE 
        WHEN DATEDIFF(NOW(), u.created_at) <= 30 THEN 'New (0-30 days)'
        WHEN DATEDIFF(NOW(), u.created_at) <= 90 THEN 'Medium (31-90 days)'
        ELSE 'Old (90+ days)'
    END AS user_tenure,
    COUNT(DISTINCT u.id) AS users,
    COUNT(DISTINCT p.id) AS posts,
    COUNT(DISTINCT l.photo_id) AS likes_given,
    COUNT(DISTINCT c.id) AS comments_made
FROM users u
LEFT JOIN photos p ON u.id = p.user_id
LEFT JOIN likes l ON u.id = l.user_id
LEFT JOIN comments c ON u.id = c.user_id
GROUP BY user_tenure;

-- 2. posting time pattern 
SELECT 
    HOUR(created_at) AS hour_of_day,
    COUNT(*) AS total_posts
FROM photos
GROUP BY HOUR(created_at)
ORDER BY total_posts DESC; 

-- 3. Engagement received based on post time
SELECT 
    HOUR(p.created_at) AS post_hour,
    COUNT(DISTINCT l.user_id) AS likes,
    COUNT(DISTINCT c.id) AS comments,
    ROUND((COUNT(DISTINCT l.user_id) + COUNT(DISTINCT c.id)) / COUNT(DISTINCT p.id), 2) AS avg_engagement
FROM photos p
LEFT JOIN likes l ON p.id = l.photo_id
LEFT JOIN comments c ON p.id = c.photo_id
GROUP BY HOUR(p.created_at)
ORDER BY avg_engagement DESC;

-- Subjective question - 5 
WITH follower_counts AS (
    SELECT followee_id AS user_id,
           COUNT(*) AS follower_count
    FROM follows
    GROUP BY followee_id
),
photo_counts AS (
    SELECT user_id,
           COUNT(*) AS photo_count
    FROM photos
    GROUP BY user_id
),
engagement AS (
    SELECT p.user_id,
           COUNT(DISTINCT l.user_id, l.photo_id) AS total_likes,
           COUNT(DISTINCT c.id) AS total_comments
    FROM photos p
    LEFT JOIN likes l ON l.photo_id = p.id
    LEFT JOIN comments c ON c.photo_id = p.id
    GROUP BY p.user_id
)
SELECT
    u.id AS user_id,
    u.username,
    fc.follower_count,
    pc.photo_count,
    e.total_likes,
    e.total_comments,
    ROUND((e.total_likes + e.total_comments) / pc.photo_count, 2) AS avg_engagement_per_post,
    ROUND(
        (e.total_likes + e.total_comments) / pc.photo_count / fc.follower_count * 100, 2
    ) AS engagement_rate_pct
FROM users u
JOIN follower_counts fc ON fc.user_id = u.id
JOIN photo_counts pc ON pc.user_id = u.id
JOIN engagement e ON e.user_id = u.id
WHERE fc.follower_count >= 20        -- minimum reach threshold
  AND pc.photo_count >= 3            -- filter out one-off posters
ORDER BY engagement_rate_pct DESC, fc.follower_count DESC
LIMIT 20;

-- Subjective question - 6 
WITH activity AS (
    SELECT u.id AS user_id,
           u.username,
           COUNT(DISTINCT p.id) AS photos_posted,
           COUNT(DISTINCT l.photo_id) AS likes_given,
           COUNT(DISTINCT c.id) AS comments_given
    FROM users u
    LEFT JOIN photos p ON p.user_id = u.id
    LEFT JOIN likes l ON l.user_id = u.id
    LEFT JOIN comments c ON c.user_id = u.id
    GROUP BY u.id, u.username
),
received AS (
    SELECT p.user_id,
           COUNT(DISTINCT l.user_id, l.photo_id) AS likes_received,
           COUNT(DISTINCT cm.id) AS comments_received
    FROM photos p
    LEFT JOIN likes l ON l.photo_id = p.id
    LEFT JOIN comments cm ON cm.photo_id = p.id
    GROUP BY p.user_id
),
social AS (
    SELECT u.id AS user_id,
           (SELECT COUNT(*) FROM follows f WHERE f.followee_id = u.id) AS followers,
           (SELECT COUNT(*) FROM follows f WHERE f.follower_id = u.id) AS following
    FROM users u
)
SELECT
    a.user_id,
    a.username,
    a.photos_posted,
    a.likes_given,
    a.comments_given,
    COALESCE(r.likes_received, 0) AS likes_received,
    COALESCE(r.comments_received, 0) AS comments_received,
    s.followers,
    s.following,
    CASE
        WHEN a.photos_posted = 0 AND a.likes_given = 0 AND a.comments_given = 0
            THEN 'At-Risk'
        WHEN a.photos_posted >= 5 AND s.followers >= 20
            THEN 'Influencer'
        WHEN a.photos_posted = 0 AND (a.likes_given > 0 OR a.comments_given > 0)
            THEN 'Passive Engager'
        WHEN a.photos_posted BETWEEN 1 AND 4 AND (a.likes_given + a.comments_given) >= 5
            THEN 'Active Creator'
        WHEN s.following > s.followers * 3
            THEN 'Content Consumer (High Follow Ratio)'
        ELSE 'Casual User'
    END AS segment
FROM activity a
JOIN received r ON r.user_id = a.user_id
JOIN social s ON s.user_id = a.user_id
ORDER BY segment, a.photos_posted DESC;

-- subjective question - 8
WITH tenure AS (
    SELECT id AS user_id,
           username,
           created_at,
           DATEDIFF(CURDATE(), created_at) AS days_on_platform
    FROM users
),
content_activity AS (
    SELECT user_id,
           COUNT(*) AS photos_posted
    FROM photos
    GROUP BY user_id
),
outbound_engagement AS (
    -- how much this user engages with OTHERS (comments/likes given)
    SELECT u.id AS user_id,
           COUNT(DISTINCT l.photo_id) AS likes_given,
           COUNT(DISTINCT c.id) AS comments_given
    FROM users u
    LEFT JOIN likes l ON l.user_id = u.id
    LEFT JOIN comments c ON c.user_id = u.id
    GROUP BY u.id
),
inbound_engagement AS (
    -- how much engagement this user's own content earns back
    SELECT p.user_id,
           COUNT(DISTINCT l.user_id, l.photo_id) AS likes_received,
           COUNT(DISTINCT cm.id) AS comments_received
    FROM photos p
    LEFT JOIN likes l ON l.photo_id = p.id
    LEFT JOIN comments cm ON cm.photo_id = p.id
    GROUP BY p.user_id
),
social_graph AS (
    SELECT u.id AS user_id,
           (SELECT COUNT(*) FROM follows f WHERE f.followee_id = u.id) AS followers,
           (SELECT COUNT(*) FROM follows f WHERE f.follower_id = u.id) AS following
    FROM users u
)
SELECT
    t.user_id,
    t.username,
    t.days_on_platform,
    COALESCE(ca.photos_posted, 0) AS photos_posted,
    oe.likes_given,
    oe.comments_given,
    COALESCE(ie.likes_received, 0) AS likes_received,
    COALESCE(ie.comments_received, 0) AS comments_received,
    sg.followers,
    sg.following,
    ROUND(
        (oe.likes_given + oe.comments_given) /
        NULLIF(COALESCE(ie.likes_received, 0) + COALESCE(ie.comments_received, 0), 1),
    2) AS reciprocity_ratio,
    ROUND(
        (COALESCE(ca.photos_posted,0) + oe.likes_given + oe.comments_given)
        / NULLIF(t.days_on_platform, 0) * 30,
    2) AS monthly_activity_score
FROM tenure t
JOIN outbound_engagement oe ON oe.user_id = t.user_id
LEFT JOIN content_activity ca ON ca.user_id = t.user_id
LEFT JOIN inbound_engagement ie ON ie.user_id = t.user_id
JOIN social_graph sg ON sg.user_id = t.user_id
WHERE t.days_on_platform >= 180              -- established tenure, not a new/fly-by-night account
  AND (oe.likes_given + oe.comments_given) >= 10   -- meaningfully engages with others
ORDER BY reciprocity_ratio DESC, monthly_activity_score DESC
LIMIT 25;

-- subjective question - 9
SELECT 
    u.id,
    u.username,
    COALESCE(f.followers, 0) AS followers,
    COALESCE(p.posts, 0) AS posts,
    COALESCE(eng.likes_received, 0) AS likes_received,
    COALESCE(eng.comments_received, 0) AS comments_received,
    COALESCE(act.likes_given, 0) AS likes_given,
    COALESCE(act.comments_made, 0) AS comments_made,
    
    ROUND(
        (COALESCE(eng.likes_received, 0) + COALESCE(eng.comments_received, 0)) * 1.0 
        / NULLIF(COALESCE(p.posts, 0), 0), 2
    ) AS engagement_rate,

    -- Optimized Ambassador Score
    ROUND(
        (COALESCE(f.followers, 0) * 0.30) +
        (COALESCE(p.posts, 0) * 0.20) +
        ((COALESCE(eng.likes_received, 0) + COALESCE(eng.comments_received, 0)) * 0.30) +
        ((COALESCE(act.likes_given, 0) + COALESCE(act.comments_made, 0)) * 0.20)
    , 2) AS ambassador_score

FROM users u

-- Followers
LEFT JOIN (
    SELECT followee_id, COUNT(*) AS followers
    FROM follows
    GROUP BY followee_id
) f ON u.id = f.followee_id

-- Posts
LEFT JOIN (
    SELECT user_id, COUNT(*) AS posts
    FROM photos
    GROUP BY user_id
) p ON u.id = p.user_id

-- Engagement Received
LEFT JOIN (
    SELECT 
        ph.user_id,
        COUNT(DISTINCT l.user_id) AS likes_received,
        COUNT(DISTINCT c.id) AS comments_received
    FROM photos ph
    LEFT JOIN likes l ON ph.id = l.photo_id
    LEFT JOIN comments c ON ph.id = c.photo_id
    GROUP BY ph.user_id
) eng ON u.id = eng.user_id

-- Activity Given
LEFT JOIN (
    SELECT 
        user_id,
        COUNT(DISTINCT photo_id) AS likes_given,
        COUNT(*) AS comments_made
    FROM (
        SELECT user_id, photo_id FROM likes
        UNION ALL
        SELECT user_id, photo_id FROM comments
    ) activity
    GROUP BY user_id
) act ON u.id = act.user_id

WHERE COALESCE(p.posts, 0) >= 2 
  AND COALESCE(f.followers, 0) >= 5

ORDER BY ambassador_score DESC
LIMIT 15;